import { Routes } from '@angular/router';

import { DocpubComponent } from './docpub.component';

export const DocpubRoutes: Routes = [
  { path: '', component: DocpubComponent }
];
